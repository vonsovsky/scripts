﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Encog.Neural.Networks;
using Encog.Neural.Networks.Layers;
using Encog.Neural.NeuralData;
using Encog.Neural.Data.Basic;
using Encog.Neural.Networks.Training;
using Encog.Neural.Networks.Training.Propagation.Back;
using Encog.Neural.Data;
using Encog.Persist;
using Encog.Engine.Network.Activation;
using System.IO;
using System.Globalization;

namespace Neural
{
    class Program
    {




        static void Main(string[] args)
        {
            BasicNetwork sit;
            sit = new BasicNetwork();
            sit.AddLayer(new BasicLayer(new ActivationSigmoid(), true, 3));
            sit.AddLayer(new BasicLayer(new ActivationSigmoid(), true, 15));
            sit.AddLayer(new BasicLayer(new ActivationSigmoid(), true, 1));
            sit.Structure.FinalizeStructure();
            sit.Reset();

            string[] train = File.ReadAllLines("Train.txt");

            CultureInfo ci = CultureInfo.CreateSpecificCulture("en-US");
            int k = train.Length;
            double[][] trenovaciVstup = new double[k][];
            double[][] trenovaciVystup = new double[k][];
            for (int i = 0; i < k; i++)
            {
                trenovaciVystup[i] = new double[] { 1.0 };
                string[] tmp = train[i].Split('\t', ' ');
                trenovaciVstup[i] = new double[3];
                trenovaciVstup[i][0] = double.Parse(tmp[1], ci) / 24.0;
                trenovaciVstup[i][1] = (double.Parse(tmp[2], ci) + 90.0) / 180.0;
                trenovaciVstup[i][2] = double.Parse(tmp[3], ci) / 1000.0;
            }
            for (int l = 0; l < k; l++) Console.WriteLine("{0} {1} {2}", trenovaciVstup[l][0], trenovaciVstup[l][1], trenovaciVstup[l][2]);
            INeuralDataSet tMnozina = new BasicNeuralDataSet(trenovaciVstup, trenovaciVystup);
            ITrain ucitel = new Backpropagation(sit, tMnozina, 0.3, 0.2);

            do
            {
                ucitel.Iteration(100); Console.WriteLine(ucitel.Error);
            } while (Console.ReadLine() == "g");

            string o1 = "", o2 = "", o3 = "";
            /*string s;
            while ((s = Console.ReadLine()) != "") {
                string[] lk = s.Split(' ');
                double[] cin = new double[3];
                
                cin[0] = double.Parse(lk[0]);
                cin[1] = double.Parse(lk[1]);
                cin[2] = double.Parse(lk[2]);
                sit.Compute(cin, vystup);
                Console.WriteLine(vystup[0]);
            }
            Console.ReadLine();*/

            double[] vystup = new double[1];
            double min; string id;
            string[] dataVar = File.ReadAllLines("data-var.txt");
            List<string> klíče = new List<string>();
            List<double> položky = new List<double>();
            for (int i = 0; i < dataVar.Length; i++)
            {
                if (dataVar[i] != "")
                {

                    string[] lk = dataVar[i].Split('\t', ' ');
                    klíče.Add(lk[0]);
                    o1 += "\r\n" + lk[0];
                    double[] cin = new double[3];

                    cin[0] = double.Parse(lk[1], ci) / 24.0;
                    cin[1] = (double.Parse(lk[2], ci) + 90.0) / 180.0;
                    cin[2] = double.Parse(lk[3], ci) / 1000.0;
                    o3 += "\r\n" + lk[3].ToString();
                    sit.Compute(cin, vystup);
                    položky.Add(vystup[0]);
                    o2 += "\r\n" + vystup[0].ToString();
                    Console.WriteLine("{0} {1} {2} {3}", cin[0], cin[1], cin[2], vystup[0]);
                }
            }


            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(klíče[klíče.Count - i - 1]);
            }
            File.WriteAllText("o1.txt", o1);
            File.WriteAllText("o2.txt", o2);
            File.WriteAllText("o3.txt", o3);
            Console.ReadLine();

            //Console.WriteLine(ucitel.Error);


        }
    }
}
